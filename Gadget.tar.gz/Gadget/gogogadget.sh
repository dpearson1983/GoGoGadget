mkdir fftw
mkdir gsl
tar -xzvf fftw-2.1.5.tar.gz
cd fftw-2.1.5
./configure --enable-mpi --enable-type-prefix --prefix=/home/dpearson/Gadget/fftw
make
make install
cd ..
tar -xvzf gsl-2.4.tar.gz
cd gsl-2.4
./configure --prefix=/home/dpearson/Gadget/gsl
make
make install
cd ../Gadget-2.0.7/Gadget2
make
cd /home/dpearson/Gadget/N-GenIC
make


